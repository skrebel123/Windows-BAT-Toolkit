NETWORK SECURITY BAT TOOLKIT
20 defensive Windows network-security scripts.

Run administrative scripts as Administrator.
Use firewall changes only on systems you own or are authorized to manage.
Review commands before execution.
