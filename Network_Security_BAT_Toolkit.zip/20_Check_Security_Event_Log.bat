@echo off
powershell -NoProfile -Command "Get-WinEvent -FilterHashtable @{LogName=Security;Id=4625} -MaxEvents 20 | Select TimeCreated,Id | Format-Table -AutoSize"
pause
