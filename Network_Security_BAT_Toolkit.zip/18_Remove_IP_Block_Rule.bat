@echo off
set /p "IP=Enter previously blocked IP: "
if "%IP%"=="" exit /b
netsh advfirewall firewall delete rule name="BAT_Block_%IP%"
pause
