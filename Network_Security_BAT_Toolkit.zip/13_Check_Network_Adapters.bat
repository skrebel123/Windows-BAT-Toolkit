@echo off
powershell -NoProfile -Command "Get-NetAdapter | Format-Table -AutoSize Name,InterfaceDescription,Status,LinkSpeed,MacAddress"
pause
