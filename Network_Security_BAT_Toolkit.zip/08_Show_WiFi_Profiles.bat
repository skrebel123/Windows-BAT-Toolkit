@echo off
netsh wlan show profiles
pause
