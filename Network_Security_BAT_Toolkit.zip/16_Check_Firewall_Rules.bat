@echo off
netsh advfirewall firewall show rule name=all dir=in
pause
