@echo off
set /p "IP=Enter IP address to block: "
if "%IP%"=="" exit /b
netsh advfirewall firewall add rule name="BAT_Block_%IP%" dir=in action=block remoteip=%IP% enable=yes
netsh advfirewall firewall add rule name="BAT_Block_%IP%" dir=out action=block remoteip=%IP% enable=yes
echo Block rule created.
pause
