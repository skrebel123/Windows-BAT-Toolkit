@echo off
netsh advfirewall show allprofiles
pause
