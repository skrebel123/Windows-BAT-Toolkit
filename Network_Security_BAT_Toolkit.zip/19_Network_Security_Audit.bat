@echo off
set "OUT=%USERPROFILE%\Desktop\Network_Security_Audit.txt"
(echo ===== NETWORK SECURITY AUDIT =====&date /t&time /t&echo.&hostname&echo.&ipconfig /all&echo.&netstat -ano&echo.&netsh advfirewall show allprofiles&echo.&powershell -NoProfile -Command "Get-MpComputerStatus | Select AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled") > "%OUT%"
echo Audit saved to %OUT%
pause
