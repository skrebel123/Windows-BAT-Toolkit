@echo off
powershell -NoProfile -Command "Get-SmbServerConfiguration | Select EnableSMB1Protocol,RequireSecuritySignature | Format-List"
pause
