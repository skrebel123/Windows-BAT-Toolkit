@echo off
netsh advfirewall set allprofiles state on
echo Windows Firewall enabled.
pause
