@echo off
netstat -ano | findstr LISTENING
pause
