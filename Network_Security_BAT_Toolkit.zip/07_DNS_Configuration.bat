@echo off
ipconfig /all | findstr /i "DNS Servers DHCP Server"
pause
