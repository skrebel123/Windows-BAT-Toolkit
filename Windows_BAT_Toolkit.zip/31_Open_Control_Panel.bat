@echo off
control
